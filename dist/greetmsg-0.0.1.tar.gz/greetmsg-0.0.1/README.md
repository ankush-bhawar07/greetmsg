# greetmsg
A python package for greet message
