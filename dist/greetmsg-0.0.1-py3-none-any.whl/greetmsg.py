def greet(name=None):
    if name is None:
        print("Hello There,\nThanks for installing our python package\nEnjoy Coding with us")
    else:
        print(f"Hello {name},\nThanks for installing our python package\nEnjoy Coding with us")
        